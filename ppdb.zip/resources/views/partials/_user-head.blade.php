<header class="header-area header-sticky wow slideInDown background-header" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav text-center">
            <!-- ***** Logo Start ***** -->
            <a href="{{route('dashboard.user')}}" class="logo">
            </a>
            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            {{-- <ul class="nav">
              <li><a href="{{route('dashboard.user')}}" class="active">Home</a></li>
              <li><a href="category.html">Category</a></li>
              <li><a href="listing.html">Listing</a></li>
              <li><a href="contact.html">Contact Us</a></li>
              <li></li>
            </ul>
            <a class='menu-trigger'>
                <span>Menu</span>
            </a> --}}
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
