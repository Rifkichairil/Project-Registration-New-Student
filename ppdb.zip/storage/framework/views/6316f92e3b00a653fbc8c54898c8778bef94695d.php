<?php $__env->startSection('style'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="popular-categories">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="section-heading">
            <h3  class="mt-1 text-black">DI PORTAL PENERIMAAN PESERTA DIDIK BARU (PPDB) ONLINE</h4>
            <h3   class="mt-1 text-black">SDIT BAHRUL FIKRI </h3>
            <h3   class="mt-1 text-black">TAHUN AJARAN 2021/2022 </h3>
            
          </div>
        </div>
        <div class="col-lg-12">
          <div class="naccs">
            <div class="grid">
              <div class="row">
                <div class="col-lg-3">
                  <div class="menu">
                    <div class="first-thumb active">
                      <div class="thumb">
                        <span class="icon"><img src="<?php echo e(asset('file/icon/home.png')); ?>" alt=""></span>
                        Beranda
                      </div>
                    </div>
                    <div>
                      <div class="thumb">
                        <span class="icon"><img src="<?php echo e(asset('file/icon/info.png')); ?>" alt=""></span>
                        Info Pendaftaran
                      </div>
                    </div>
                    <div  >
                      <div class="thumb ">
                        <span class="icon"><img src="<?php echo e(asset('file/icon/writing.png')); ?>" alt=""></span>
                        Isi Formulir Pendaftaran
                      </div>
                    </div>
                    <div>
                      <div class="thumb">
                        <span class="icon"><img src="<?php echo e(asset('file/icon/promotion.png')); ?>" alt=""></span>
                        Pengumuman Hasil Seleksi
                      </div>
                    </div>
                    <div class="last-thumb">
                      <div class="thumb">
                        <span class="icon"><img src="<?php echo e(asset('file/icon/telephone.png')); ?>" alt=""></span>
                        Kontak Kami
                      </div>
                    </div>
                  </div>
                </div>

                
                <?php echo $__env->make('page.user._tab-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laragon\www\ppdb\resources\views/page/user/index.blade.php ENDPATH**/ ?>