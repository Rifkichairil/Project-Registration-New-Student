<?php $__env->startSection('content'); ?>

<div class="col-12 grid-margin stretch-card">
    
    <div class="card">
        <div class="card-body">
            <h4 class="mb-4">Data Pribadi Siswa</h4>
            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Nama Lengkap</label>
                        <p class="card-description"><?php echo e($account->nama_lengkap); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">NIK</label>
                        <p class="card-description"><?php echo e($account->nik); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">No. KK</label>
                        <p class="card-description"><?php echo e($account->no_kk); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">No. Akte Lahir</label>
                        <p class="card-description"><?php echo e($account->akte); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">NISN</label>
                        <p class="card-description">
                            <?php echo e((@$account->nisn == null) ?  '-' : $account->nisn); ?> </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Gender</label>
                        <p class="card-description"><?php echo e($account->gender); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Tempat, Tanggal Lahir</label>
                        <p class="card-description"><?php echo e($account->tempat); ?>, <?php echo e(\Carbon\Carbon::parse($account->tgl_lahir)->format('d F Y')); ?></p>

                    </div>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col-lg-12">
                    <div class="form-group ">
                        <label for="exampleInputName1">Alamat</label>
                        <p class="card-description"><?php echo e($account->alamat); ?>, Rt. <?php echo e($account->rt); ?>, Rw. <?php echo e($account->rw); ?>, Kel. <?php echo e($account->kelurahan); ?>, Kec. <?php echo e($account->kecamatan); ?>, Kota <?php echo e($account->kota); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Minat</label>
                        <p class="card-description"><?php echo e($account->minat); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Bakat</label>
                        <p class="card-description"><?php echo e($account->bakat); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Hobby</label>
                        <p class="card-description"><?php echo e($account->hoby); ?></p>
                    </div>
                </div>
            </div>
<hr>
            <h4 class="mb-4">Pendidikan Asal Siswa</h4>
            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Pendidikan Asal</label>
                        <p class="card-description"><?php echo e($account->pendidikan->pend_asal); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Tinggi Badan</label>
                        <p class="card-description"><?php echo e($account->pendidikan->tinggi_badan); ?> Cm</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Berat Badan</label>
                        <p class="card-description"><?php echo e($account->pendidikan->berat_badan); ?> Kg</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-group ">
                        <label for="exampleInputName1">Alamat</label>
                        <p class="card-description"><?php echo e($account->pendidikan->pend_alamat); ?></p>
                    </div>
                </div>

            </div>
<hr>
            <h4 class="mb-4">Pendidikan Mutasi Siswa</h4>
            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Pendidikan Asal Mutasi</label>
                        
                        <p class="card-description"> <?php echo e((@$account->mutasi->pend_asal_mutasi == null) ?  '-' : $account->mutasi->pend_asal_mutasi); ?> </p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Alamat</label>
                        <p class="card-description"><?php echo e((@$account->mutasi->pend_alamat_mutasi == null) ?  '-' : $account->mutasi->pend_alamat_mutasi); ?></p>
                    </div>
                </div>
            </div>
<hr>
            <h4 class="mb-4">Orang Tua Siswa</h4>
            <h4 class="mb-4">Ayah</h4>

            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Nama Lengkap Ayah</label>
                        <p class="card-description"><?php echo e($account->waliayah->wali_nama_ayah); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">NIK Ayah</label>
                        <p class="card-description"><?php echo e($account->waliayah->nik_ayah); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">No. Telpon ayah</label>
                        <p class="card-description"><?php echo e($account->waliayah->no_telp_ayah); ?> </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Pekerjaan Ayah</label>
                        <p class="card-description"><?php echo e($account->waliayah->pekerjaan_ayah); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Tempat Tanggal Lahir Ayah</label>
                        <p class="card-description"><?php echo e($account->waliayah->tempat_ayah); ?>, <?php echo e(\Carbon\Carbon::parse($account->waliayah->tgl_lahir_ayah)->format('d F Y')); ?></p>
                    </div>
                </div>
            </div>

            <h4 class="mb-4 mt-4">Ibu</h4>
            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Nama Lengkap Ibu</label>
                        <p class="card-description"><?php echo e($account->waliibu->wali_nama_ibu); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">NIK Ibu</label>
                        <p class="card-description"><?php echo e($account->waliibu->nik_ibu); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">No. Telpon Ibu</label>
                        <p class="card-description"><?php echo e($account->waliibu->no_telp_ibu); ?> </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Pekerjaan Ibu</label>
                        <p class="card-description"><?php echo e($account->waliibu->pekerjaan_ibu); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="form-group ">
                        <label for="exampleInputName1">Tempat, Tanggal Lahir Ibu</label>
                        <p class="card-description"><?php echo e($account->waliibu->tempat_ibu); ?>, <?php echo e(\Carbon\Carbon::parse($account->waliayah->tgl_lahir_ibu)->format('d F Y')); ?></p>
                    </div>
                </div>
            </div>

            <hr>
            <h4 class="mb-4">Penghasilan Orang Tua Siswa</h4>
            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group ">
                            <p class="card-description"><?php echo e($account->gaji); ?></p>

                    </div>
                </div>
            </div>

<hr>
            <div class="row mt-4">
                <div class="float-end">
                    <a href="<?php echo e(route('edit', $account->uuid)); ?>" type="submit" class="btn btn-primary mr-2">Edit</a>
                    <form action="<?php echo e(route('status', $account->id)); ?>" method="POST" style="display: inline-block">
                        <?php echo csrf_field(); ?>
                        <?php if($account->status == 1): ?>
                            <button type="submit" class="btn btn-danger ">
                                Uverifikasi Siswa
                            </button>
                        <?php else: ?>
                            <button type="submit" class="btn btn-success ">
                                Verifikasi Siswa
                            </button>
                        <?php endif; ?>
                    </form>
                    <a href="<?php echo e(route('dashboard.user')); ?>" class="btn btn-light mr-2">Kembali</a>
                </div>
            </div>



        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laragon\www\ppdb\resources\views/page/user/detail.blade.php ENDPATH**/ ?>