<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('ppdb.png')); ?>">

    <title>Pendaftaran Peserta Didik Baru</title>
    <link rel="stylesheet" href="<?php echo e(asset('admin_asset/vendor/feather/feather.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_asset/vendor/ti-icons/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_asset/vendor/css/vendor.bundle.base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_asset/vendor/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_asset/vendor/ti-icons/css/themify-icons.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_asset/js/select.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_asset/css/vertical-layout-light/style.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>

</head>
<body>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-scroller">

    <!-- partial:partials/_navbar.html -->
    <?php echo $__env->make('partials._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- partial -->

    <div class="container-fluid page-body-wrapper">

        <!-- partial:partials/_settings-panel.html -->
        
        <!-- partial -->

        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('partials._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->

    <div class="main-panel">
        <div class="content-wrapper">
            
            <div class="row">
                <div class="col-md-12 grid-margin">
                <div class="row">
                    <div class="col-12 col-xl-8 mb-4 mb-xl-0">
                    <h3 class="font-weight-bold">Welcome Admin ! </h3>
                    
                    </div>
                    
                </div>
                </div>
            </div>
            

            <?php echo $__env->yieldContent('content'); ?>

        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <?php echo $__env->make('partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
    </div>
    <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
</div>

<script src="<?php echo e(asset('admin_asset/vendor/js/vendor.bundle.base.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/vendor/chart.js/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/vendor/datatables.net/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/vendor/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/js/dataTables.select.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/js/off-canvas.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/js/hoverable-collapse.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/js/template.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/js/settings.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/js/todolist.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/js/dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/js/Chart.roundedBarCharts.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/js/file-upload.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/js/typeahead.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/js/select2.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>


</body>

</html>

<?php /**PATH D:\Laragon\www\ppdb\resources\views/app.blade.php ENDPATH**/ ?>