<footer>

        <div class="col-lg-12">
          <div class="sub-footer">
            <p>Copyright  © 2021 SDIT Bahrul Fikri, All Rights Reserved.
          </div>
        </div>
      </div>
    </div>
  </footer>
<?php /**PATH D:\Laragon\www\ppdb\resources\views/partials/_user-footer.blade.php ENDPATH**/ ?>