<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4 mb-4 stretch-card transparent">
        <div class="card card-tale">
            <div class="card-body">
                <p class="mb-4">Siswa Terdaftar</p>
                <p class="fs-30 mb-2"><?php echo e($accounts->count()); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4 stretch-card transparent">
        <div class="card card-tale">
            <div class="card-body">
                <p class="mb-4">Status Pending</p>
                <p class="fs-30 mb-2"><?php echo e($pending); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4 stretch-card transparent">
        <div class="card card-tale">
            <div class="card-body">
                <p class="mb-4">Status Aktif</p>
                <p class="fs-30 mb-2"><?php echo e($active); ?></p>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
            <div class="dloat-end">

            </div>

            <div class="d-flex justify-content-between mb-4">
                <h4 class="card-title">Data Siswa</h4>
                <a href="<?php echo e(route('excel')); ?>" type="submit" class="btn btn-primary mr-2"  target="_blank">Export Excel</a>
            </div>

            <div class="table-responsive">
                <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th class="th-sm">Nama Lengkap Siswa</th>
                        <th class="th-sm">Nama Ayah</th>
                        <th class="th-sm">Nama Ibu</th>
                        <th class="th-sm">Gender </th>
                        <th class="th-sm">Status</th>
                        <th class="th-sm" style="width: 15%">Aksi </th>
                    </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($account->nama_lengkap); ?></td>
                            <td><?php echo e($account->waliayah->wali_nama_ayah); ?></td>
                            <td><?php echo e($account->waliibu->wali_nama_ibu); ?></td>
                            <td><?php echo e($account->gender); ?></td>
                            <?php if($account->status == 0): ?>
                                <td><label class="badge badge-danger">Pending</label></td>
                            <?php else: ?>
                                <td><label class="badge badge-success">Aktif</label></td>
                            <?php endif; ?>
                            <td>
                                <a href="<?php echo e(route('detail', $account->uuid)); ?>" class="btn btn-primary btn-icon-text"> <i class="ti-file btn-icon-prepend"></i>Detail </a>
                                <?php if($account->status == 1): ?>
                                    <a href="<?php echo e(route('print', $account->uuid)); ?>" class="btn btn-info btn-icon-text"> <i class="ti-download btn-icon-prepend"></i>Cetak </a>
                                <?php endif; ?>
                                <form action="<?php echo e(route('delete', $account->uuid)); ?>" method="POST" style="display: inline-block">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-icon-text"> <i class="ti-trash btn-icon-prepend"></i></button>
                                </form>


                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
            </div>
            </div>
        </div>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $('#dtBasicExample').DataTable();
        $('.dataTables_length').addClass('bs-select');
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laragon\www\ppdb\resources\views/page/admin/index.blade.php ENDPATH**/ ?>