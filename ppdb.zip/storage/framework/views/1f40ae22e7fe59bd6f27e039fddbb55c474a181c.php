    <!DOCTYPE html>
    <html lang="en">

    <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login | Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?php echo e(asset('admin_asset/vendor/feather/feather.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_asset/vendor/ti-icons/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_asset/vendor/css/vendor.bundle.base.css')); ?>">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('admin_asset/css/vertical-layout-light/style.css')); ?>">
    <!-- endinject -->
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('ppdb.png')); ?>">


    </head>

    <body>
    <div class="container-scroller">
        <div class="container-fluid page-body-wrapper full-page-wrapper">
        <div class="content-wrapper d-flex align-items-center auth px-0">
            <div class="row w-100 mx-0">
            <div class="col-lg-4 mx-auto">
                <div class="auth-form-light text-left py-5 px-4 px-sm-5">
                
                    
                


                <h4 class="text-center">Hello! Welcome</h4>
                <h6 class="font-weight-light text-center">Login to continue.</h6>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('auth')); ?>" method="POST" class="pt-3">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                    <input type="email" name="email"  class="form-control form-control-lg" id="email" placeholder="email">
                    <span style="color: red"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                    <input type="password" name="password"  class="form-control form-control-lg" id="password" placeholder="Password">
                    <span style="color: red"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>

                    </div>
                    <div class="mt-3">
                    <button type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">LOG IN</button>
                    </div>
                </form>
                </div>
            </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?php echo e(asset('admin_asset/vendor/js/vendor.bundle.base.js')); ?>"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo e(asset('admin_asset/js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_asset/js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_asset/js/template.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_asset/js/settings.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_asset/js/todolist.js')); ?>"></script>
    <!-- endinject -->
    </body>

    </html>
<?php /**PATH D:\Laragon\www\ppdb\resources\views/login.blade.php ENDPATH**/ ?>